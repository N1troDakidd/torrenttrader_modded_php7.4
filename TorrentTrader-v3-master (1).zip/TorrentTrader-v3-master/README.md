TorrentTrader 2.8 Updated to use mysqli and php 7+ (7.4 recommended) Now named TorrentTrader 3.0
![](gitimage/1.jpg)
