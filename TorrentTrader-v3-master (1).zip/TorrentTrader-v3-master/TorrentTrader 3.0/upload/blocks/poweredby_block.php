<?php
begin_block("Powered By");
?>

<center>
    <a href="http://validator.w3.org/check?uri=referer" target="_blank"><img
      src="images/misc/xhtml.png" alt="Valid XHTML 1.0 Transitional" title="Valid XHTML 1.0 Transitional" height="31" width="88" /></a>
      
    <a href="http://www.php.net" target="_blank"><img
      src="images/misc/php.png" alt="PHP Hypertext Preprocessor" title="PHP Hypertext Preprocessor" height="31" width="88" /></a>
      
    <a href="http://www.mysql.com/" target="_blank"><img
      src="images/misc/mysql.png" alt="MySQL" title="MySQL" height="31" width="88" /></a>
</center>
  
<?php
end_block();
?>