<?php
begin_block(T_("DONATE"));
echo "<br /><br /><center>This would need to contain your donation code, or something. maybe even a paypal link</center><br /><br />";
end_block();
?>
